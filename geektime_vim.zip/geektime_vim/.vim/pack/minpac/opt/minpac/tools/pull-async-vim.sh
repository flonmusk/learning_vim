#!/bin/sh
git subtree pull --prefix autoload/minpac https://github.com/prabirshrestha/async.vim.git master --squash

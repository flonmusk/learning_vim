# test alignment feature
keys('\\\\\\\\A')
keys('\\\\\\\\a')
